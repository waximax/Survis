﻿define({ entries : {
    "Abba2021": {
        "abstract": "In this work, we present an approach for automatic translation of tock-CSP into Timed Automata (TA) for Uppaal to facilitate using Uppaal in reasoning about temporal specifications of tock-CSP models. The process algebra tock-CSP provides textual notations for modelling discrete-time behaviours, with the support of tools for automatic verification. Automatic verification of TA with a graphical notation is supported by Uppaal. The two approaches provide facilities for automatic verification. For instance, liveness requirements are difficult to specify with the constructs of tock-CSP, but they are easy to specify and verify in Uppaal. We have developed a translation technique and a tool based for translating tock-CSP into a network of small TAs for capturing the compositional structure of tock-CSP. For validating the rules, we begin with an experimental approach based on finite approximations to trace sets. Then, we explore using structural induction to establish the correctness.",
        "author": "Abba, A., Cavalcanti, A., & Jacob, J",
        "doi": "10.1007/978-3-030-92137-8_5",
        "keywords": "type:system, Translation, tock-CSP, Timed-Automata",
        "number": "07",
        "title": "Temporal Reasoning Through Automatic Translation of tock-CSP into Timed Automata {SurVis}",
        "type": "book",
        "url": "https://repository.uel.ac.uk/item/8wz07",
        "year": "2021"
    },
    "Cherukuri2022": {
        "abstract": "[Contextandmotivation]Requirementsformalisationfacilitatesrea- soning about inconsistencies, detection of ambiguities, and identification critical issues in system models. Temporal logic formulae are the natural choice when it comes to formalise requirements associated to desired system behaviours. [Ques- tion/problem] Understanding and mastering temporal logic requires a formal background. Means are therefore needed to make temporal logic formulae in- terpretable by engineers, domain experts and other stakeholders involved in the development process. [Principal ideas/results] In this paper, we propose to use a neural machine translation tool, named OPENNMT, to translate Linear Tem- poral Logic (LTL) formulae into corresponding natural language descriptions. Our results show that the translation system achieves an average BLEU (BiLin- gual Evaluation Understudy) score of 93.53%, which corresponds to high-quality translations. [Contribution] Our neural model can be applied to assess if re- quirements have been correctly formalised. This can be useful to requirements analysts, who may have limited confidence with LTL, and to other stakeholders involved in the requirements verification process. Overall, our research preview contributes to bridging the gap between formal methods and requirements engi- neering, and opens to further research in explainable formal methods.",
        "author": "Cherukuri, H., Ferrari, A., & Spoletini, P",
        "doi": "10.1007/978-3-030-98464-9_7",
        "journal": "IEEE Transactions on Visualization and Computer Graphics",
        "keywords": "type:system, Requirements engineering \u00b7 Formal Methods \u00b7 Machine Translation \u00b7 Neural Networks \u00b7 Temporal Logic \u00b7 LTL \u00b7 Natural Language Processing \u00b7 NLP.",
        "number": "03",
        "title": "Towards Explainable Formal Methods: From LTL to Natural Language with Neural Machine Translation {SurVis}",
        "type": "Proceedings",
        "url": "https://www.researchgate.net/publication/359102190_Towards_Explainable_Formal_Methods_From_LTL_to_Natural_Language_with_Neural_Machine_Translation",
        "year": "2022"
    },
    "Gnezdilova2023": {
        "abstract": "Currently, requirements for control software written in natural language are often formulated ambiguously and incompletely. Controlled natural languages (CNLs) can solve this problem, at the same time maintaining flexibility for writing and conveying requirements in an intuitive and common way. The creation of domain-specific controlled natural languages nowadays is under active development. In this paper, we suggest CNL which is based on event-driven semantics. This language is intended for describing the temporal properties of cyber-physical systems. We develop our CNL using a number of natural language patterns build for classes of requirements expressed in Event-Driven Temporal Logic formalism (EDTL). Due to formal semantics of EDTL, the suggested CNL is also unambiguous and can be translated into logic formulas. As a result, the proposed CNL provides an auxiliary tool to improve communication quality between different participants in the industrial system development process: customers, requirements engineers, developers, and others. Therefore, the solution helps to reduce the number of errors in the formulation of requirements at earlier stages of development.",
        "author": "Gnezdilova, A. V., Garanina, N. O., Staroletov, S. M., & Zyubin, V. E",
        "doi": "10.1109/EDM58354.2023.10225047",
        "journal": "IEEE Transactions on Visualization and Computer Graphics",
        "keywords": "type:system, controlled natural language, cyber-physical system, requirements, linear temporal logic, event-driven temporal logic",
        "number": "05",
        "title": "Towards Controlled Natural Language for Event-Driven Temporal Requirements {SurVis}",
        "type": "Proceedings",
        "url": "https://ieeexplore.ieee.org/abstract/document/10225047",
        "year": "2023"
    },
    "Gordon2023": {
        "abstract": "Interactive proof assistants are computer programs carefully constructed to check a human-designed proof of a mathe- matical claim with high confidence in the implementation. However, this only validates truth of a formal claim, which may have been mistranslated from a claim made in nat- ural language. This is especially problematic when using proof assistants to formally verify the correctness of software with respect to a natural language specification. The trans- lation from informal to formal remains a challenging, time- consuming process that is difficult to audit for correctness.",
        "author": "Gordon, C. S., & Matskevich, S",
        "doi": "10.1145/3622758.3622890",
        "keywords": "type:system, Natural language, formal specification, catego- rial grammar, computational linguistics",
        "number": "08",
        "title": "Trustworthy Formal Natural Language Specifications {SurVis}",
        "type": "Proceedings",
        "url": "https://dl-acm-org.nottingham.idm.oclc.org/doi/abs/10.1145/3622758.3622890",
        "year": "2023"
    },
    "Guo2022": {
        "abstract": "Stateflow is a graphical language for modeling hierarchical transition systems, well-known for the complexity of its semantics, which is only informally explained in its user manual. Formal analysis and verification of Stateflow models usually proceed by first translating a subset of Stateflow to a formal language with precise semantics. Most existing work address only \u201csafe\u201d subset of Stateflow and ignore the most complex semantic issues. Moreover, it is difficult to balance simplicity of the translation algorithm with conciseness of the resulting model. In this paper, we describe a two-stage process for translating a large subset of Stateflow to Hybrid CSP, where the first stage is mostly syntax-directed and addresses each feature of Stateflow separately, and the second stage is a code optimization step that simplifies the resulting model using information from static analysis. We further incorporate this method into translation of Simulink models, in particular consider Stateflow charts triggered by various signal sources and function calls. The translation process is thoroughly validated using a hand-designed set of benchmarks, as well as larger case studies from existing work.",
        "author": "Guo, P., Zhan, B., Xu, X., Wang, S., & Sun, W",
        "doi": "10.1016/j.sysarc.2022.102665",
        "journal": "IEEE Transactions on Visualization and Computer Graphics",
        "keywords": "type:system, Simulink/Stateflow, Hybrid CSP, Formal semantics",
        "number": "06",
        "title": "Translating a large subset of stateflow to hybrid CSP with code optimization {SurVis}",
        "type": "article",
        "url": "https://www-sciencedirect-com.nottingham.idm.oclc.org/science/article/pii/S1383762122001783?via%3Dihub",
        "year": "2022"
    },
    "Kumar2020": {
        "abstract": "Users often query a search engine with a specific question in mind and often these queries are keywords or sub-sentential fragments. For example, if the users want to know the answer for \"What's the capital of USA\", they will most probably query \"capital of USA\" or \"USA capital\" or some keyword-based variation of this. For example, for the user entered query \"capital of USA\", the most probable question intent is \"What's the capital of USA?\". In this paper, we are proposing a method to generate well-formed natural language question from a given keyword-based query, which has the same question intent as the query. Conversion of keyword-based web query into a well-formed question has lots of applications, with some of them being in search engines, Community Question Answering (CQA) website and bots communication. We found a synergy between query-to-question problem with standard machine translation(MT) task. We have used both Statistical MT (SMT) and Neural MT (NMT) models to generate the questions from the query. We have observed that MT models perform well in terms of both automatic and human evaluation.",
        "author": "Kumar, A., Dandapat, S., & Chordia, S",
        "doi": "https://doi.org/10.48550/arXiv.2002.02631",
        "keywords": "type:system, Natural Language Generation, Machine Translation, NLP",
        "number": "04",
        "title": "Translating Web Search Queries into Natural Language Questions {SurVis}",
        "type": "article",
        "url": "https://www.proquest.com/docview/2352828488?accountid",
        "year": "2020"
    },
    "Luckcuck2021": {
        "abstract": "Communication is a critical part of enabling multi-agent systems to cooperate. This means that applying formal methods to protocols governing communication within multi-agent systems provides useful confidence in its reliability. In this paper, we describe the formal verification of a complex communication protocol that coordinates agents merging maps of their environment. The protocol was used by the LFC team in the 2019 edition of the Multi-Agent Programming Contest (MAPC). Our specification of the protocol is written in Communicating Sequential Processes (CSP), which is a well-suited approach to specifying agent communication protocols due to its focus on concurrent communicating systems. We validate the specification's behaviour using scenarios where the correct behaviour is known, and verify that eventually all the maps have merged.",
        "author": "Luckcuck, Matt, Cardoso, Rafael C",
        "doi": "https://doi.org/10.48550/arXiv.2106.04512",
        "keywords": "type:system, Formal Verification, Map Merging Protocol, CSP, MAPC, Multi-Agent Systems",
        "number": "01",
        "title": "Formal Verification of a Map Merging Protocol in the Multi-Agent Programming Contest {SurVis}",
        "type": "article",
        "url": "https://arxiv.org/abs/2106.04512",
        "year": "2021"
    },
    "MacConville2022": {
        "abstract": "Software verification is an important tool in establishing the reliability of critical systems. One potential area of application is in the field of robotics, as robots take on more tasks in both day-to-day areas and highly specialised domains. Robots are usually given a plan to follow, if there are errors in this plan the robot will not perform reliably. The capability to check plans for errors in advance could prevent this. Python is a popular programming language in the robotics domain, through the use of the Robot Operating System (ROS) and various other libraries. Python\u2019s Turtle package provides a mobile agent, which we formally model here using Communicating Sequential Processes (CSP). Our interactive toolchain CSP2Turtle with CSP model and Python components, enables Turtle plans to be verified in CSP before being executed in Python. This means that certain classes of errors can be avoided, and provides a starting point for more detailed verification of Turtle programs and more complex robotic systems. We illustrate our approach with examples of robot navigation and obstacle avoidance in a 2D grid-world.",
        "author": "MacConville, D., Farrell, M., Luckcuck, M., & Monahan, R",
        "doi": "10.4204/EPTCS.362.4",
        "keywords": "type:system, Python, CSP",
        "number": "10",
        "title": "Modelling the Turtle Python library in CSP {SurVis}",
        "type": "Proceedings",
        "url": "https://www.proquest.com/docview/2692478628?pq-origsite",
        "year": "2022"
    },
    "MacConville2023": {
        "abstract": "Software verification is an important approach to establishing the reliability of critical systems. One important area of application is in the field of robotics, as robots take on more tasks in both day-to-day areas and highly specialised domains. Our particular interest is in checking the plans that robots are expected to follow to detect errors that would lead to unreliable behaviour. Python is a popular programming language in the robotics domain through the use of the Robot Operating System (ROS) and various other libraries. Python\u2019s Turtle package provides a mobile agent, which we formally model here using Communicating Sequential Processes (CSP) . Our interactive toolchain CSP2Turtle with CSP models and Python components enables plans for the turtle agent to be verified using the FDR model-checker before being executed in Python. This means that certain classes of errors can be avoided, providing a starting point for more detailed verification of Turtle programs and more complex robotic systems. We illustrate our approach with examples of robot navigation and obstacle avoidance in a 2D grid-world. We evaluate our approach and discuss future work, including how our approach could be scaled to larger systems.",
        "author": "MacConville, D., Farrell, M., Luckcuck, M., & Monahan, R",
        "doi": "10.3390/robotics12020062",
        "keywords": "type:system, software verification; robotics; Python; CSP",
        "number": "09",
        "title": "CSP2Turtle: Verified Turtle Robot Plans \u2020 {SurVis}",
        "type": "article",
        "url": "https://www.proquest.com/docview/2806604541?accountid",
        "year": "2023"
    },
    "Zhai2020": {
        "abstract": "Formal program specifications are essential for various software engineering tasks, such as program verification, program synthesis, code debugging and software testing. However, manually inferring formal program specifications is not only time-consuming but also error-prone. In addition, it requires substantial expertise. Natural language comments contain rich semantics about behaviors of code, making it feasible to infer program specifications from comments. Inspired by this, we develop a tool, named C2S, to automate the specification synthesis task by translating natural language com- ments into formal program specifications. Our approach firstly constructs alignments between natural language word and speci- fication tokens from existing comments and their corresponding specifications. Then for a given method comment, our approach as- sembles tokens that are associated with words in the comment from the alignments into specifications guided by specification syntax and the context of the target method. Our tool successfully synthe- sizes 1,145 specifications for 511 methods of 64 classes in 5 different projects, substantially outperforming the state-of-the-art. The gen- erated specifications are also used to improve a number of software engineering tasks like static taint analysis, which demonstrates the high quality of the specifications. ,",
        "author": "Zhai, J., Shi, Y., Pan, M., Zhou, G., Liu, Y., Fang, C., Ma, S., Tan, L., & Zhang, X",
        "doi": "10.1145/3368089.3409716",
        "keywords": "type:system,Formal Specification, Comment, Natural Language Processing",
        "number": "02",
        "title": "C2S: Translating natural language comments to formal program specifications {SurVis}",
        "type": "Proceedings",
        "url": "https://dl.acm.org/doi/10.1145/3368089.3409716",
        "year": "2020"
    }
}});